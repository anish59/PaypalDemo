package bbt.com.paypaldemo;

public class Apis {
    public static final String BASE_URL="http://10.0.2.2/braintree/";
    public static final String GET_ACCESS_TOKEN="main.php";
    public static final String CHECK_OUT="checkout.php";
    public static final int OK_RESPONSE = 200;
}
